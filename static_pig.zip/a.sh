cp ../../arm_build/libhorizon_static_so.so lib/
#cp ../../arm_build/clean_data/libfilter.a lib/
cp ../../arm_build/libdetector.a lib/
#cp ../../arm_build/platforms/libdetect_api.a lib/
