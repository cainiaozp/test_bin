#include <iostream>
#include <vector>
#include <opencv2/opencv.hpp>

/* 初始化计算资源 */
void init_aisystem_static();

/* 释放计算资源 */
void uninit_aisystem_static();

/* 推理计算静息猪
   输入参数: 
       image: 图片数据
       railType: 轨道类型，1: U轨道，2: 直轨
   返回值: 
       box_info: 猪只坐标[一只猪由六个浮点数表示: x、 y、 w、 h、 标签、 置信度]
       pig_pose_result: 猪只姿势[0: 卧, 1: 站立]
*/
void run_static_detector(cv::Mat &image, int railType, std::vector<float> &box_info, std::vector<int> &pig_pose_result);

int main(int argc, char **argv) {
    init_aisystem_static();
    
    cv::Mat image = cv::imread("1.jpg");
    if(image.empty()){
        printf("image is empty\n");
    }

    std::vector<float> box_info;
    std::vector<int> pig_pose_result;
    int railType = 1;
    run_static_detector(image, railType, box_info, pig_pose_result);

    uninit_aisystem_static();
    return 0;
}
