export LD_LIBRARY_PATH=../lib
