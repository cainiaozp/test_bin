#!/usr/bin/env bash

# dataquality          1.52 0.80
# spray_detector       0.49 0.41
#

GCC_ROOT=/opt/gcc-ubuntu-9.3.0-2020.03-x86_64-aarch64-linux-gnu
export CC=${GCC_ROOT}/bin/aarch64-linux-gnu-gcc
export CXX=${GCC_ROOT}/bin/aarch64-linux-gnu-g++

#rm -rf arm_build
#mkdir arm_build
#cd arm_build

BUILD_TYPE=Release
#BUILD_TYPE=Debug
cmake .. -DCMAKE_BUILD_TYPE=${BUILD_TYPE}

#make -j4 ai_system_test
#make -j4 filter_algorithm_test_
make -j4 horizon_static
#scp modules/horizon_test  root@172.17.0.183:/userdata/ai/.deb/bin/
#scp clean_data/ai_system_test  root@172.17.0.99:/userdata/ai/.deb/bin/
#sshpass -p "MYops1qaz@WSX" scp -P 55555 -r *horizon_test*     ops@117.159.228.204:~/.bin/1/
